<?php

namespace app\controller;

use think\Facade\Request;
use app\model\UserInfo;
use think\facade\Session;
use think\facade\Cookie;

class Reg
{
    public function reg()
    {
        /*
         * 注册流程
         * 用户发起注册请求
         * 服务器验证数据是否符合规范
         * 服务器验证邮箱
         * 服务器分发账号以及唯一id
         * 注册结束
         */

        if (Request::method() == 'POST') {
            //获取提交的数值
            $data = Request::param();
            $mail = $data['mail'];
            $name = $data['name'];
            $code = $data['code'];
            $pass = $data['pass'];
            $repass = $data['repass'];
            $device = $data['device'];
            $head = $data['head'];
            //验证合法性
            if ($repass == $pass || $pass != null || $pass != '') {
                if ($name != '' || strlen($name) > 10) {
                    if ($device != '' || $device != null) {
                        if ($mail == '' || $mail == "null") {
                            $rs = [
                                'msg' => '注册失败，邮箱为空',
                                'code' => 400
                            ];
                            return json($rs);
                        } else {
                            if ($code == Cookie::get('code')) {
                                //参数无误，分发账号
                                $account = get_account();
                                $db = new UserInfo();
                                $db->reg($mail, $name, $device, $pass, $account, $head);
                                $rs = [
                                    'code' => 200,
                                    'msg' => '注册成功'
                                ];
                                return json($rs);
                            } else {
                                $rs = [
                                    'code' => 400,
                                    'msg' => '注册失败，验证码错误！'
                                ];
                                return json($rs);
                            }
                        }
                    } else {
                        $rs = [
                            'msg' => '注册失败，没有获取到设备识别码',
                            'code' => 400
                        ];
                        return json($rs);
                    }
                } else {
                    $rs = [
                        'msg' => '注册失败，用户名过长',
                        'code' => 400
                    ];
                    return json($rs);
                }
            } else {
                $rs = [
                    'msg' => '注册失败，请保证两次密码相同',
                    'code' => 400
                ];
                return json($rs);
            }
        } else {
            return '你想干森么?';
        }

    }

    public function code()
    {
        $data = Request::param();
        $mail = $data['mail'];
        //邮箱验证
        $code = creat_code();
        $pd = Session::has('time');
        if ($pd) {
            Cookie::set('code', $code, 300);
            if (time() - Session::get('time') > 60) {
                $nr = "您的验证码为：" . '<strong>' . $code . '</strong>' . '5分钟内有效！' . '<br>' . '如非您本人操作，请联系管理员3200180046解决，如果不在意，请忽略本邮件';
                return json(mailer("注册验证邮件请查收！", $nr, $mail));
            } else {
                $rs = [
                    'code' => 400,
                    'msg' => '60s内仅可发送一次',
                ];
                return json($rs);
            }
        } else {
            Session::set('time', time());
            Cookie::set('code', $code, 300);
            $nr = "您的验证码为：" . '<strong>' . $code . '</strong>' . '5分钟内有效！' . '<br>' . '如非您本人操作，请联系管理员3200180046解决，如果不在意，请忽略本邮件';
            return json(mailer("注册验证邮件请查收！", $nr, $mail));
        }

    }

//    public function test()
//    {
//        $db = new UserInfo();
//        $mail = '3200180046@qq.com';
//        $name = '逆风';
//        $device = 'admin';
//        $pass = 'df661150';
//        $account = "123456";
//        $head = 'admin';
//        $db->reg($mail, $name, $device, $pass, $account, $head);
//    }

}
