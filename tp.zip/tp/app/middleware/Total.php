<?php


namespace app\middleware;

class Total
{
    public function handle($request, \Closure $next)
    {

        return $next($request);
    }
}