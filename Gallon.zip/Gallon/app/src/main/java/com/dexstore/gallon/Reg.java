package com.dexstore.gallon;

import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Reg extends AppCompatActivity {
    //加载界面

    public static final String TAG="Reg";
    private OkHttpClient okHttpClient;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);

        //startActivity(new Intent(Reg.this, Nb.class));
        //finish();
        // 开启错误提示
        TextInputLayout inputLayout = findViewById(R.id.ip_nc);

        inputLayout.setErrorEnabled(true);
// 开启计数
        inputLayout.setCounterEnabled(true);
// 设置输入最大长度
        inputLayout.setCounterMaxLength(15);
        //编辑框更新监听
        inputLayout.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(inputLayout.getEditText().getText().toString().trim().length()>15){
                    inputLayout.setError("用户名长度超出15字符");
                    inputLayout.setErrorTextColor(ColorStateList.valueOf(0XFFFF0000));
                    inputLayout.setHelperTextColor(ColorStateList.valueOf((0XFFFF0000)));
                }else{
                    inputLayout.setError(null);
                }
            }
        });

        //长按发送验证码
        findViewById(R.id.ip_cd).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                SharedPreferences share = getSharedPreferences("Session",MODE_PRIVATE);
                String sessionid= share.getString("sessionid","null");
                TextInputLayout maill = findViewById(R.id.ip_yx);
                String mail = maill.getEditText().getText().toString();
                okHttpClient = new OkHttpClient();
                FormBody formBody = new FormBody.Builder()
                        .add("mail",mail)
                        .build();
                Request request =  new Request.Builder()
                        .url("http://www.dexstorer.top/index.php/reg/code")
                        .addHeader("cookie",sessionid)
                        .post(formBody)
                        .build();
                //准备请求对象
                Call call = okHttpClient.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        Toast.makeText(getApplicationContext(), "逆风这个几把代码写错了等着修复吧\n加QQ3200180046骚扰他", Toast.LENGTH_SHORT).show();
                        Log.e("出错",e.getMessage());

                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        Log.i(TAG, "返回"+ response.body().string());
                        String sessionid = response.headers().get("Set-Cookie");
                        SharedPreferences share = Reg.this.getSharedPreferences("Session",MODE_PRIVATE);
                        SharedPreferences.Editor edit = share.edit();//编辑文件
                        edit.putString("sessionid",sessionid);
                        edit.commit();
                        Looper.prepare();
                        Toast.makeText(getApplicationContext(), "乌拉~发送成功！", Toast.LENGTH_SHORT).show();
                        Looper.loop();
                    }
                });
                return false;
            }
        });
        findViewById(R.id.bt_zc).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                获取输入数值

                TextInputLayout codel = findViewById(R.id.ip_cd);
                TextInputLayout userl = findViewById(R.id.ip_nc);
                TextInputLayout passl = findViewById(R.id.ip_mm);
                TextInputLayout repassl = findViewById(R.id.ip_mmcf);
                TextInputLayout maill = findViewById(R.id.ip_yx);

                String user = userl.getEditText().getText().toString();
                String pass = passl.getEditText().getText().toString();
                String mail = maill.getEditText().getText().toString();
                String repass = repassl.getEditText().getText().toString();
                String code = codel.getEditText().getText().toString();

            if (user.equals("")||pass.equals("")||mail.equals("")){
                Toast.makeText(getApplicationContext(), "账号或密码不完整", Toast.LENGTH_SHORT).show();
            }else if (repass.equals(pass)){
                //okhttp请求器
                okHttpClient = new OkHttpClient();
                //进行注册，开始填写表单
                FormBody formBody = new FormBody.Builder()
                        .add("name",user)
                        .add("pass",pass)
                        .add("repass",repass)
                        .add("device",mail)
                        .add("mail",mail)
                        .add("code",code)
                        .add("head","wind")
                        .build();
                Request request =  new Request.Builder()
                        .url("http://www.dexstore.top/index.php/reg/reg")
                        .post(formBody)
                        .build();
                //准备请求对象
                Call call = okHttpClient.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        Looper.prepare();
                        Toast.makeText(getApplicationContext(), "逆风这个几把代码写错了等着修复吧\n加QQ3200180046骚扰他", Toast.LENGTH_SHORT).show();
                        Log.e("出错",e.getMessage());
                        Looper.loop();
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        Log.i(TAG, "返回"+ response.body().string());
                    }
                });
            }else{
                Toast.makeText(getApplicationContext(), "两次密码不相同", Toast.LENGTH_SHORT).show();
            }

/*

 */

            }
        });
    }

}
