package com.dexstore.gallon;


import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttp;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class Nb extends AppCompatActivity {

    public static final String TAG="Nb";
    private OkHttpClient okHttpClient;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nb);


        //按钮点击事件
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                okHttpClient = new OkHttpClient();
                //进行注册，开始填写表单
                FormBody formBody = new FormBody.Builder()
                        .add("password","df661150")
                        .add("mod","newreply")
                        .add("address","未获取")
                        .add("repquote","null")
                        .add("params_version_code","460")
                        .add("message","[怀疑]")
                        .add("comment_id","null")
                        .add("tid","1612886")
                        .add("username","a9pn5731h4")
                        .build();
                Request request =  new Request.Builder()
                        .url("http://m.gateway.7723api.com/v3/bbs/c")
                        .post(formBody)
                        .addHeader("sign","bbc4e017b59d525c7dd4e16888e18701")
                        .addHeader("sign-type","md5")
                        .addHeader("time-stamp","1649463905")
                        .addHeader("charset","utf8")
                        .addHeader("app-id","7723cn_android_jmb_phone")
                        .addHeader("method","bbs.c")
                        .addHeader("vers-code","460")
                        .addHeader("format","json")
                        .addHeader("version","3.0.0")
                        .addHeader("agent_code","update")
                        .addHeader("token","9a056b348e3b51efa9a6a42d4a2d75d1")
                        .addHeader("wwwid","2577088")
                        .addHeader("enable-base64","1")
                        .addHeader("did","310051f3e2e17ea4")
                        .addHeader("nonce-str","z7P0aYluVTKDBkHqeYvidCo3p6DZx05D")
                        .addHeader("system-version","28")
                        .addHeader("Content-Length","185")
                        .addHeader("Content-Type","application/x-www-form-urlencoded")
                        .addHeader("Host","m.gateway.7723api.com")
                        .addHeader("Connection","Keep-Alive")
                        .addHeader("Accept-Enccoding","gzip")
                        .addHeader("User-Agent","okhttp/3.12.0")
                        .build();
                //准备请求对象
                Call call = okHttpClient.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        Toast.makeText(getApplicationContext(), "致命错误", Toast.LENGTH_SHORT).show();
                        Log.e("出错",e.getMessage());

                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        Log.i(TAG, "返回"+ response.body().string());
                    }
                });
            }
        });
    }
}
