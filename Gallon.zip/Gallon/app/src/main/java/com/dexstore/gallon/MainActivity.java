package com.dexstore.gallon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
//import android.os.Bundle;
import android.os.CountDownTimer;
//import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //初始化计时器
    private TextView textView;
    private CountDownTimer timer;

    //加载界面
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }


    private void initView() {

//设置文本
        textView = (TextView) findViewById(R.id.textview);

        //构建成员方法类使用timer创建一个CountDownTimer类，并传入参数
        //第一个参数：倒计时的毫秒数，第二个参数接收onTick回调的时间间隔
        timer = new CountDownTimer(3000, 10) {

            @Override
            public void onTick(long millisUntilFinished) {
                //倒计时显示文本秒数 +1实现非零归一操作

                textView.setText(millisUntilFinished / 1000 + 1 + "秒");

            }

            @Override
            public void onFinish() {
//            界面结束事件，不创建会报错。。。
                startActivity(new Intent(MainActivity.this, Reg.class));
                finish();
            }


        };
        timer.start();
    }

    @Override
    protected void onDestroy() {
        //界面销毁事件

        super.onDestroy();
        if (timer != null) {
            timer.cancel();
            //退出倒计时
        }

    }
}